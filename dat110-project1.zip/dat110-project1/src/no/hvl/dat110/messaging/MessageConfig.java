package no.hvl.dat110.messaging;

public class MessageConfig {

	public static final int SEGMENTSIZE = 128;
	
	public static final int MESSAGINGPORT = 8080;
	public static final String MESSAGINGHOST = "localhost";
}
