package no.hvl.dat110.rpc;

public class RPCCommon {

	public static byte RPIDSTOP = 0;
}
